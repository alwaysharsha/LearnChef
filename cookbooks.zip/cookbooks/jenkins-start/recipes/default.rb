#
# Cookbook:: jenkins-start
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.

service "tomcat" do
  action :start
end

