#
# Cookbook:: CreateZipFile
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.

execute 'createzip' do
	command 'tar czf somefile.tar.gz /etc/gconf'
	cwd '/var/www/html'
end
