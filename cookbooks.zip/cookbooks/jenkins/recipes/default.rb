#
# Cookbook:: jenkins
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.

package ['tomcat'] 

execute 'downlad' do
	command 'wget http://mirrors.jenkins.io/war-stable/latest/jenkins.war'
	cwd '/usr/share/tomcat/webapps'
end
