#
# Cookbook:: install
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.

package ['zip'] 

package ['git']

package ['wget']

package ['curl']
