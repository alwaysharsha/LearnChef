#
# Cookbook:: UnZip
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.


directory '/var/www/html/1' do
  mode '0755'
  action :create
end


execute 'unzip' do
	command 'tar xvzf /var/www/html/somefile.tar.gz --directory /var/www/html/1'
	cwd '/var/www/html'
end
